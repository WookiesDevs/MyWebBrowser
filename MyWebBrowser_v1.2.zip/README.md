# MyWebBrowser - Navigateur Web Haute Performance

## Description
Navigateur web moderne développé avec PyQt5 et QtWebEngine, offrant des fonctionnalités avancées de navigation, téléchargement, et sécurité.

## Installation Rapide

### Prérequis
- Python 3.7+
- Système d'exploitation : Windows 10+, macOS 10.14+, ou Linux Ubuntu 18.04+

### Installation
```bash
pip install -r requirements.txt
python navigateur_pyqt.py
```

## Fonctionnalités
- ✅ Navigation par onglets
- ✅ Mode navigation privée
- ✅ Gestionnaire de téléchargements
- ✅ Indicateur de sécurité HTTPS
- ✅ Gestion des favoris
- ✅ Cache intelligent
- ✅ Interface moderne avec dégradés

## Documentation Complète
Consultez le fichier `GUIDE_INSTALLATION.txt` pour des instructions détaillées.

## Raccourcis Principaux
- `Ctrl+T` : Nouvel onglet
- `Ctrl+Shift+N` : Navigation privée
- `Ctrl+D` : Ajouter aux favoris
- `Ctrl+Shift+Y` : Gestionnaire de téléchargements

## Support
Pour toute question ou problème, consultez la section "Résolution des problèmes" dans le guide d'installation.