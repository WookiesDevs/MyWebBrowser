#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Navigateur Web Haute Performance avec PyQt5 et QtWebEngine
Version optimisée avec mise en cache et performances améliorées
"""

import sys
import os
import json
import threading
from datetime import datetime, timedelta
from PyQt5.QtWidgets import (QApplication, QMainWindow, QVBoxLayout, QHBoxLayout, 
                           QWidget, QPushButton, QLineEdit, QTabWidget, QMenuBar, 
                           QMenu, QAction, QStatusBar, QToolBar, QMessageBox,
                           QInputDialog, QListWidget, QDialog, QDialogButtonBox,
                           QProgressBar, QLabel, QSplashScreen, QFileDialog)
from PyQt5.QtWebEngineWidgets import QWebEngineView, QWebEnginePage, QWebEngineProfile, QWebEngineSettings, QWebEngineDownloadItem
from PyQt5.QtCore import QUrl, Qt, pyqtSignal, QTimer, QThread, pyqtSlot, QSize, QStandardPaths
from PyQt5.QtGui import QIcon, QKeySequence, QPixmap, QFont
import gc

class OptimizedWebPage(QWebEnginePage):
    """Page web optimisée avec gestion avancée des ressources"""
    
    def __init__(self, profile, parent=None):
        super().__init__(profile, parent)
        self.setup_optimizations()
    
    def setup_optimizations(self):
        """Configurer les optimisations de performance"""
        settings = self.settings()
        
        # Optimisations de performance
        settings.setAttribute(QWebEngineSettings.JavascriptEnabled, True)
        settings.setAttribute(QWebEngineSettings.PluginsEnabled, False)  # Désactiver les plugins pour plus de vitesse
        settings.setAttribute(QWebEngineSettings.AutoLoadImages, True)
        settings.setAttribute(QWebEngineSettings.LocalStorageEnabled, True)
        settings.setAttribute(QWebEngineSettings.LocalContentCanAccessRemoteUrls, False)
        settings.setAttribute(QWebEngineSettings.XSSAuditingEnabled, True)
        
        # Optimisations mémoire
        settings.setAttribute(QWebEngineSettings.HyperlinkAuditingEnabled, False)
        settings.setAttribute(QWebEngineSettings.ErrorPageEnabled, True)
        
        # Cache et stockage
        settings.setAttribute(QWebEngineSettings.LocalStorageEnabled, True)
    
    def acceptNavigationRequest(self, url, navigation_type, is_main_frame):
        """Filtrer les requêtes pour optimiser les performances"""
        url_str = url.toString()
        
        # Bloquer certains types de contenu pour améliorer les performances
        blocked_domains = ['doubleclick.net', 'googleadservices.com', 'googlesyndication.com']
        if any(domain in url_str for domain in blocked_domains):
            return False
            
        return super().acceptNavigationRequest(url, navigation_type, is_main_frame)

class NavigateurWebOptimise(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("MyWebBrowser")
        self.setGeometry(100, 100, 1400, 900)
        
        # Configuration de performance
        self.cache_size = 100 * 1024 * 1024  # 100MB cache
        self.max_onglets = 10
        
        # Données avec cache
        self.favoris = self.charger_favoris()
        self.historique = []
        self.cache_pages = {}
        self.derniere_activite = datetime.now()
        
        # Profil web optimisé
        self.setup_web_profile()
        
        # Interface
        self.creer_interface()
        self.creer_menu()
        self.creer_barre_outils()
        
        # Timers d'optimisation
        self.setup_optimization_timers()
        
        # Page d'accueil
        self.aller_accueil()
        
        # Appliquer le style moderne
        self.appliquer_style_moderne()
    
    def setup_web_profile(self):
        """Configurer le profil web pour les performances"""
        self.profile = QWebEngineProfile.defaultProfile()
        
        # Configuration du cache
        cache_path = os.path.join(os.path.expanduser("~"), ".navigateur_cache")
        os.makedirs(cache_path, exist_ok=True)
        self.profile.setCachePath(cache_path)
        self.profile.setHttpCacheMaximumSize(self.cache_size)
        
        # Configuration de stockage persistant
        storage_path = os.path.join(os.path.expanduser("~"), ".navigateur_storage")
        os.makedirs(storage_path, exist_ok=True)
        self.profile.setPersistentStoragePath(storage_path)
        
        # User agent moderne pour compatibilité
        user_agent = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                     "(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36")
        self.profile.setHttpUserAgent(user_agent)
        
        # Configuration des téléchargements
        self.profile.downloadRequested.connect(self.gerer_telechargement)
        
        # Créer le profil privé
        self.setup_private_profile()
    
    def setup_private_profile(self):
        """Configurer le profil de navigation privée"""
        # Créer un profil off-the-record (privé)
        self.private_profile = QWebEngineProfile()
        
        # Configuration pour la navigation privée
        self.private_profile.setHttpUserAgent(
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
            "(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
        )
        
        # Désactiver le cache persistant pour la navigation privée
        self.private_profile.setHttpCacheType(QWebEngineProfile.MemoryHttpCache)
        self.private_profile.setHttpCacheMaximumSize(50 * 1024 * 1024)  # 50MB en mémoire seulement
        
        # Désactiver le stockage persistant
        self.private_profile.setPersistentCookiesPolicy(QWebEngineProfile.NoPersistentCookies)
        
        # Configuration des téléchargements pour le mode privé
        self.private_profile.downloadRequested.connect(self.gerer_telechargement)
    
    def setup_optimization_timers(self):
        """Configurer les timers d'optimisation"""
        # Timer pour nettoyer la mémoire
        self.timer_nettoyage = QTimer()
        self.timer_nettoyage.timeout.connect(self.nettoyer_memoire)
        self.timer_nettoyage.start(300000)  # Toutes les 5 minutes
        
        # Timer pour sauvegarder automatiquement
        self.timer_sauvegarde = QTimer()
        self.timer_sauvegarde.timeout.connect(self.sauvegarde_automatique)
        self.timer_sauvegarde.start(60000)  # Toutes les minutes
    
    def appliquer_style_moderne(self):
        """Appliquer un style moderne et coloré avec des dégradés"""
        style = """
        QMainWindow {
            background: qlineargradient(x1:0, y1:0, x2:1, y2:1, 
                stop:0 #2E3440, stop:0.5 #3B4252, stop:1 #434C5E);
            color: #ECEFF4;
        }
        
        QTabWidget::pane {
            border: 2px solid #5E81AC;
            border-radius: 8px;
            background: qlineargradient(x1:0, y1:0, x2:0, y2:1, 
                stop:0 #4C566A, stop:1 #3B4252);
        }
        
        QTabBar::tab {
            background: qlineargradient(x1:0, y1:0, x2:0, y2:1, 
                stop:0 #88C0D0, stop:1 #5E81AC);
            color: #2E3440;
            padding: 8px 16px;
            margin-right: 2px;
            border-top-left-radius: 8px;
            border-top-right-radius: 8px;
            font-weight: bold;
        }
        
        QTabBar::tab:selected {
            background: qlineargradient(x1:0, y1:0, x2:0, y2:1, 
                stop:0 #A3BE8C, stop:1 #8FBCBB);
            color: #2E3440;
            border: 2px solid #EBCB8B;
        }
        
        QTabBar::tab:hover {
            background: qlineargradient(x1:0, y1:0, x2:0, y2:1, 
                stop:0 #81A1C1, stop:1 #88C0D0);
        }
        
        /* Style spécial pour les onglets privés */
        QTabBar::tab[private="true"] {
            background: qlineargradient(x1:0, y1:0, x2:0, y2:1, 
                stop:0 #BF616A, stop:1 #D08770);
            color: #ECEFF4;
            border: 2px solid #EBCB8B;
        }
        
        QTabBar::tab[private="true"]:selected {
            background: qlineargradient(x1:0, y1:0, x2:0, y2:1, 
                stop:0 #D08770, stop:1 #EBCB8B);
            color: #2E3440;
            border: 2px solid #BF616A;
        }
        
        QTabBar::tab[private="true"]:hover {
            background: qlineargradient(x1:0, y1:0, x2:0, y2:1, 
                stop:0 #D08770, stop:1 #BF616A);
            color: #ECEFF4;
        }
        
        QPushButton {
            background: qlineargradient(x1:0, y1:0, x2:0, y2:1, 
                stop:0 #5E81AC, stop:1 #81A1C1);
            color: #ECEFF4;
            border: 2px solid #88C0D0;
            padding: 8px 16px;
            border-radius: 6px;
            font-weight: bold;
        }
        
        QPushButton:hover {
            background: qlineargradient(x1:0, y1:0, x2:0, y2:1, 
                stop:0 #A3BE8C, stop:1 #8FBCBB);
            border: 2px solid #EBCB8B;
            color: #2E3440;
        }
        
        QPushButton:pressed {
            background: qlineargradient(x1:0, y1:0, x2:0, y2:1, 
                stop:0 #D08770, stop:1 #BF616A);
            border: 2px solid #EBCB8B;
        }
        
        QLineEdit {
            background: qlineargradient(x1:0, y1:0, x2:0, y2:1, 
                stop:0 #4C566A, stop:1 #3B4252);
            color: #ECEFF4;
            border: 2px solid #5E81AC;
            border-radius: 8px;
            padding: 8px;
            font-size: 14px;
            selection-background-color: #88C0D0;
        }
        
        QLineEdit:focus {
            border: 2px solid #A3BE8C;
            background: qlineargradient(x1:0, y1:0, x2:0, y2:1, 
                stop:0 #434C5E, stop:1 #4C566A);
        }
        
        QStatusBar {
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0, 
                stop:0 #2E3440, stop:1 #3B4252);
            color: #ECEFF4;
            border-top: 2px solid #5E81AC;
        }
        
        QMenuBar {
            background: qlineargradient(x1:0, y1:0, x2:0, y2:1, 
                stop:0 #5E81AC, stop:1 #81A1C1);
            color: #ECEFF4;
            border-bottom: 2px solid #88C0D0;
            font-weight: bold;
        }
        
        QMenuBar::item {
            background: transparent;
            padding: 8px 16px;
            border-radius: 4px;
        }
        
        QMenuBar::item:selected {
            background: qlineargradient(x1:0, y1:0, x2:0, y2:1, 
                stop:0 #A3BE8C, stop:1 #8FBCBB);
            color: #2E3440;
        }
        
        QMenu {
            background: qlineargradient(x1:0, y1:0, x2:0, y2:1, 
                stop:0 #3B4252, stop:1 #2E3440);
            color: #ECEFF4;
            border: 2px solid #5E81AC;
            border-radius: 8px;
        }
        
        QMenu::item {
            padding: 8px 20px;
            border-radius: 4px;
        }
        
        QMenu::item:selected {
            background: qlineargradient(x1:0, y1:0, x2:0, y2:1, 
                stop:0 #88C0D0, stop:1 #5E81AC);
        }
        
        QToolBar {
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0, 
                stop:0 #D08770, stop:0.3 #EBCB8B, stop:0.7 #A3BE8C, stop:1 #88C0D0);
            border: none;
            spacing: 4px;
            padding: 4px;
        }
        
        QToolBar QToolButton {
            background: qlineargradient(x1:0, y1:0, x2:0, y2:1, 
                stop:0 rgba(236, 239, 244, 0.9), stop:1 rgba(216, 222, 233, 0.9));
            color: #2E3440;
            border: 1px solid #5E81AC;
            border-radius: 6px;
            padding: 6px 12px;
            margin: 2px;
            font-weight: bold;
        }
        
        QToolBar QToolButton:hover {
            background: qlineargradient(x1:0, y1:0, x2:0, y2:1, 
                stop:0 #EBCB8B, stop:1 #D08770);
            border: 1px solid #BF616A;
        }
        
        QProgressBar {
            background: #3B4252;
            border: 2px solid #5E81AC;
            border-radius: 6px;
            text-align: center;
            color: #ECEFF4;
            font-weight: bold;
        }
        
        QProgressBar::chunk {
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0, 
                stop:0 #A3BE8C, stop:0.5 #EBCB8B, stop:1 #D08770);
            border-radius: 4px;
        }
        """
        self.setStyleSheet(style)
    
    def creer_interface(self):
        # Widget central
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        
        # Layout principal
        layout = QVBoxLayout(central_widget)
        layout.setSpacing(5)
        layout.setContentsMargins(5, 5, 5, 5)
        
        # Barre de navigation optimisée
        nav_layout = QHBoxLayout()
        nav_layout.setSpacing(5)
        
        # Boutons de navigation avec icônes améliorées
        self.btn_retour = QPushButton("⬅")
        self.btn_retour.setMaximumWidth(45)
        self.btn_retour.setToolTip("Retour (Alt+←)")
        self.btn_retour.clicked.connect(self.retour)
        nav_layout.addWidget(self.btn_retour)
        
        self.btn_avancer = QPushButton("➡")
        self.btn_avancer.setMaximumWidth(45)
        self.btn_avancer.setToolTip("Avancer (Alt+→)")
        self.btn_avancer.clicked.connect(self.avancer)
        nav_layout.addWidget(self.btn_avancer)
        
        self.btn_actualiser = QPushButton("🔄")
        self.btn_actualiser.setMaximumWidth(45)
        self.btn_actualiser.setToolTip("Actualiser (F5)")
        self.btn_actualiser.clicked.connect(self.actualiser)
        nav_layout.addWidget(self.btn_actualiser)
        
        self.btn_accueil = QPushButton("🏠")
        self.btn_accueil.setMaximumWidth(45)
        self.btn_accueil.setToolTip("Accueil (Alt+Home)")
        self.btn_accueil.clicked.connect(self.aller_accueil)
        nav_layout.addWidget(self.btn_accueil)
        
        # Barre d'adresse améliorée
        self.barre_adresse = QLineEdit()
        self.barre_adresse.setPlaceholderText("🔍 Rechercher ou entrer une URL...")
        self.barre_adresse.returnPressed.connect(self.naviguer)
        self.barre_adresse.setFont(QFont("Segoe UI", 11))
        nav_layout.addWidget(self.barre_adresse)
        
        # Bouton aller
        self.btn_aller = QPushButton("Aller")
        self.btn_aller.clicked.connect(self.naviguer)
        self.btn_aller.setToolTip("Naviguer (Entrée)")
        nav_layout.addWidget(self.btn_aller)
        
        # Bouton favoris
        self.btn_favoris = QPushButton("⭐")
        self.btn_favoris.setMaximumWidth(45)
        self.btn_favoris.setToolTip("Ajouter aux favoris (Ctrl+D)")
        self.btn_favoris.clicked.connect(self.ajouter_favori)
        nav_layout.addWidget(self.btn_favoris)
        
        # Bouton nouvel onglet
        self.btn_nouvel_onglet = QPushButton("➕")
        self.btn_nouvel_onglet.setMaximumWidth(45)
        self.btn_nouvel_onglet.setToolTip("Nouvel onglet (Ctrl+T)")
        self.btn_nouvel_onglet.clicked.connect(self.nouvel_onglet)
        nav_layout.addWidget(self.btn_nouvel_onglet)
        
        layout.addLayout(nav_layout)
        
        # Barre de progression pour le chargement
        self.barre_progression = QProgressBar()
        self.barre_progression.setVisible(False)
        self.barre_progression.setMaximumHeight(3)
        layout.addWidget(self.barre_progression)
        
        # Onglets pour les pages web
        self.onglets = QTabWidget()
        self.onglets.setTabsClosable(True)
        self.onglets.setMovable(True)
        self.onglets.tabCloseRequested.connect(self.fermer_onglet)
        self.onglets.currentChanged.connect(self.onglet_change)
        layout.addWidget(self.onglets)
        
        # Créer le premier onglet
        self.nouvel_onglet()
        
        # Barre de statut améliorée
        self.barre_statut = QStatusBar()
        self.setStatusBar(self.barre_statut)
        
        # Labels de statut
        self.label_statut = QLabel("Prêt")
        self.label_vitesse = QLabel("")
        self.label_memoire = QLabel("")
        
        self.barre_statut.addWidget(self.label_statut)
        self.barre_statut.addPermanentWidget(self.label_vitesse)
        self.barre_statut.addPermanentWidget(self.label_memoire)
        
        self.mettre_a_jour_statut_memoire()
    
    def creer_menu(self):
        menubar = self.menuBar()
        
        # Menu Fichier
        menu_fichier = menubar.addMenu('Fichier')
        
        action_nouvel_onglet = QAction('Nouvel onglet', self)
        action_nouvel_onglet.setShortcut('Ctrl+T')  # Raccourci standard des navigateurs
        action_nouvel_onglet.triggered.connect(self.nouvel_onglet)
        menu_fichier.addAction(action_nouvel_onglet)
        
        action_nouvel_onglet_prive = QAction('Nouvel onglet privé', self)
        action_nouvel_onglet_prive.setShortcut('Ctrl+Shift+N')  # Raccourci standard pour navigation privée
        action_nouvel_onglet_prive.triggered.connect(self.nouvel_onglet_prive)
        menu_fichier.addAction(action_nouvel_onglet_prive)
        menu_fichier.addAction(action_nouvel_onglet)
        
        action_fermer_onglet = QAction('Fermer l\'onglet', self)
        action_fermer_onglet.setShortcut('Ctrl+W')  # Raccourci standard des navigateurs
        action_fermer_onglet.triggered.connect(lambda: self.fermer_onglet(self.onglets.currentIndex()))
        menu_fichier.addAction(action_fermer_onglet)
        
        action_nouvelle_fenetre = QAction('Nouvelle fenêtre', self)
        action_nouvelle_fenetre.setShortcut('Ctrl+N')  # Raccourci standard des navigateurs
        action_nouvelle_fenetre.triggered.connect(self.nouvelle_fenetre)
        menu_fichier.addAction(action_nouvelle_fenetre)
        
        menu_fichier.addSeparator()
        
        action_quitter = QAction('Quitter', self)
        action_quitter.setShortcut('Ctrl+Q')  # Raccourci standard
        action_quitter.triggered.connect(self.close)
        menu_fichier.addAction(action_quitter)
        
        # Menu Navigation
        menu_nav = menubar.addMenu('Navigation')
        
        action_retour = QAction('Retour', self)
        action_retour.setShortcut('Alt+Left')  # Standard des navigateurs
        action_retour.triggered.connect(self.retour)
        menu_nav.addAction(action_retour)
        
        action_avancer = QAction('Avancer', self)
        action_avancer.setShortcut('Alt+Right')  # Standard des navigateurs
        action_avancer.triggered.connect(self.avancer)
        menu_nav.addAction(action_avancer)
        
        action_actualiser = QAction('Actualiser', self)
        action_actualiser.setShortcut('F5')  # Standard des navigateurs
        action_actualiser.triggered.connect(self.actualiser)
        menu_nav.addAction(action_actualiser)
        
        action_actualiser_force = QAction('Actualiser (forcer)', self)
        action_actualiser_force.setShortcut('Ctrl+F5')  # Standard des navigateurs
        action_actualiser_force.triggered.connect(self.actualiser_force)
        menu_nav.addAction(action_actualiser_force)
        
        action_accueil = QAction('Accueil', self)
        action_accueil.setShortcut('Alt+Home')  # Standard des navigateurs
        action_accueil.triggered.connect(self.aller_accueil)
        menu_nav.addAction(action_accueil)
        
        menu_nav.addSeparator()
        
        action_focus_adresse = QAction('Barre d\'adresse', self)
        action_focus_adresse.setShortcut('Ctrl+L')  # Standard des navigateurs
        action_focus_adresse.triggered.connect(self.focus_barre_adresse)
        menu_nav.addAction(action_focus_adresse)
        
        # Menu Favoris
        menu_favoris = menubar.addMenu('Favoris')
        
        action_ajouter_favori = QAction('Ajouter cette page', self)
        action_ajouter_favori.setShortcut('Ctrl+D')  # Standard des navigateurs
        action_ajouter_favori.triggered.connect(self.ajouter_favori)
        menu_favoris.addAction(action_ajouter_favori)
        
        action_gerer_favoris = QAction('Gérer les favoris', self)
        action_gerer_favoris.setShortcut('Ctrl+Shift+O')  # Standard des navigateurs
        action_gerer_favoris.triggered.connect(self.gerer_favoris)
        menu_favoris.addAction(action_gerer_favoris)
        
        # Menu Outils
        menu_outils = menubar.addMenu('Outils')
        
        action_rechercher = QAction('Rechercher dans la page', self)
        action_rechercher.setShortcut('Ctrl+F')  # Standard des navigateurs
        action_rechercher.triggered.connect(self.rechercher_dans_page)
        menu_outils.addAction(action_rechercher)
        
        action_zoom_plus = QAction('Zoom +', self)
        action_zoom_plus.setShortcut('Ctrl+=')  # Standard des navigateurs
        action_zoom_plus.triggered.connect(self.zoom_avant)
        menu_outils.addAction(action_zoom_plus)
        
        action_zoom_moins = QAction('Zoom -', self)
        action_zoom_moins.setShortcut('Ctrl+-')  # Standard des navigateurs
        action_zoom_moins.triggered.connect(self.zoom_arriere)
        menu_outils.addAction(action_zoom_moins)
        
        action_zoom_reset = QAction('Zoom normal', self)
        action_zoom_reset.setShortcut('Ctrl+0')  # Standard des navigateurs
        action_zoom_reset.triggered.connect(self.zoom_reset)
        menu_outils.addAction(action_zoom_reset)
        
        menu_outils.addSeparator()
        
        action_nettoyer_cache = QAction('Effacer le cache', self)
        action_nettoyer_cache.triggered.connect(self.nettoyer_cache)
        menu_outils.addAction(action_nettoyer_cache)
        
        action_optimiser = QAction('Optimiser les performances', self)
        action_optimiser.triggered.connect(self.optimiser_performances)
        menu_outils.addAction(action_optimiser)
        
        menu_outils.addSeparator()
        
        action_telechargements = QAction('Gestionnaire de téléchargements', self)
        action_telechargements.setShortcut('Ctrl+Shift+Y')
        action_telechargements.triggered.connect(self.ouvrir_gestionnaire_telechargements)
        menu_outils.addAction(action_telechargements)
        
        # Menu Aide
        menu_aide = menubar.addMenu('Aide')
        
        action_a_propos = QAction('À propos', self)
        action_a_propos.triggered.connect(self.a_propos)
        menu_aide.addAction(action_a_propos)
    
    def creer_barre_outils(self):
        toolbar = QToolBar()
        self.addToolBar(toolbar)
        
        # Sites populaires optimisés
        sites_populaires = [
            ("🔍 Google", "https://www.google.com"),
            ("📺 YouTube", "https://www.youtube.com"),
            ("💻 GitHub", "https://www.github.com"),
            ("📚 Wikipedia", "https://www.wikipedia.org"),
            ("📧 Gmail", "https://mail.google.com"),
            ("🛒 Amazon", "https://www.amazon.fr")
        ]
        
        for nom, url in sites_populaires:
            action = QAction(nom, self)
            action.triggered.connect(lambda checked, u=url: self.charger_url(u))
            toolbar.addAction(action)
    
    def nouvel_onglet(self, url=None):
        """Créer un nouvel onglet optimisé"""
        if self.onglets.count() >= self.max_onglets:
            QMessageBox.warning(self, "Limite atteinte", 
                              f"Maximum {self.max_onglets} onglets autorisés pour les performances")
            return
        
        # Créer une vue web optimisée
        vue_web = QWebEngineView()
        page = OptimizedWebPage(self.profile, vue_web)
        vue_web.setPage(page)
        
        # Connecter les signaux pour le suivi des performances
        vue_web.loadStarted.connect(self.chargement_commence)
        vue_web.loadProgress.connect(self.progression_chargement)
        vue_web.loadFinished.connect(self.chargement_termine)
        vue_web.urlChanged.connect(self.url_changee)
        vue_web.titleChanged.connect(self.titre_change)
        
        # Ajouter l'onglet
        if url:
            titre = "Chargement..."
            vue_web.setUrl(QUrl(url))
        else:
            titre = "Nouvel onglet"
            # Charger la page d'accueil au lieu de Google
            self.charger_page_accueil_dans_vue(vue_web)
        
        index = self.onglets.addTab(vue_web, titre)
        self.onglets.setCurrentIndex(index)
        
        # Marquer cet onglet comme normal (non privé) - utiliser une propriété personnalisée
        vue_web.is_private = False
        
        # Mettre à jour les boutons de navigation
        self.mettre_a_jour_boutons_navigation()
        
        return vue_web
    
    def nouvel_onglet_prive(self, url=None):
        """Créer un nouvel onglet en mode navigation privée"""
        if self.onglets.count() >= self.max_onglets:
            QMessageBox.warning(self, "Limite atteinte", 
                              f"Maximum {self.max_onglets} onglets autorisés pour les performances")
            return
        
        # Créer une vue web avec le profil privé
        vue_web = QWebEngineView()
        page = OptimizedWebPage(self.private_profile, vue_web)
        vue_web.setPage(page)
        
        # Connecter les signaux pour le suivi des performances
        vue_web.loadStarted.connect(self.chargement_commence)
        vue_web.loadProgress.connect(self.progression_chargement)
        vue_web.loadFinished.connect(self.chargement_termine)
        vue_web.urlChanged.connect(self.url_changee)
        vue_web.titleChanged.connect(self.titre_change)
        
        # Ajouter l'onglet
        if url:
            titre = "🔒 Chargement..."
            vue_web.setUrl(QUrl(url))
        else:
            titre = "🔒 Navigation privée"
            # Charger la page d'accueil privée
            self.charger_page_accueil_privee_dans_vue(vue_web)
        
        index = self.onglets.addTab(vue_web, titre)
        self.onglets.setCurrentIndex(index)
        
        # Marquer cet onglet comme privé
        vue_web.is_private = True
        
        # Mettre à jour les boutons de navigation
        self.mettre_a_jour_boutons_navigation()
        
        return vue_web
    
    def charger_page_accueil_privee_dans_vue(self, vue_web):
        """Charger la page d'accueil pour la navigation privée"""
        html_accueil_prive = """
        <!DOCTYPE html>
        <html>
        <head>
            <title>Navigation Privée - Navigateur Haute Performance</title>
            <meta charset="utf-8">
            <style>
                * { margin: 0; padding: 0; box-sizing: border-box; }
                body {
                    font-family: 'Segoe UI', -apple-system, BlinkMacSystemFont, sans-serif;
                    background: linear-gradient(135deg, #2c3e50 0%, #34495e 100%);
                    color: white;
                    min-height: 100vh;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                }
                .container {
                    max-width: 800px;
                    width: 90%;
                    background: rgba(0, 0, 0, 0.3);
                    border-radius: 20px;
                    padding: 40px;
                    backdrop-filter: blur(15px);
                    box-shadow: 0 20px 40px rgba(0,0,0,0.4);
                    text-align: center;
                    border: 2px solid rgba(255, 255, 255, 0.1);
                }
                h1 {
                    font-size: 2.5em;
                    margin-bottom: 20px;
                    background: linear-gradient(45deg, #ecf0f1, #bdc3c7);
                    -webkit-background-clip: text;
                    -webkit-text-fill-color: transparent;
                }
                .private-icon {
                    font-size: 4em;
                    margin-bottom: 20px;
                    opacity: 0.8;
                }
                .search-box {
                    margin: 30px 0;
                }
                .search-input {
                    width: 80%;
                    padding: 15px 20px;
                    font-size: 16px;
                    border: none;
                    border-radius: 25px;
                    background: rgba(255, 255, 255, 0.9);
                    color: #333;
                    outline: none;
                }
                .private-info {
                    margin-top: 30px;
                    padding: 20px;
                    background: rgba(0,0,0,0.3);
                    border-radius: 10px;
                    border-left: 4px solid #e74c3c;
                }
                .info-item {
                    margin: 10px 0;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                }
                .info-icon {
                    margin-right: 10px;
                    font-size: 1.2em;
                }
            </style>
        </head>
        <body>
            <div class="container">
                <div class="private-icon">🔒</div>
                <h1>Navigation Privée</h1>
                <p>Vos données de navigation ne seront pas enregistrées</p>
                
                <div class="search-box">
                    <input type="text" class="search-input" placeholder="🔍 Rechercher en mode privé..." 
                           onkeypress="if(event.key==='Enter') window.location.href='https://www.google.com/search?q='+encodeURIComponent(this.value)">
                </div>
                
                <div class="private-info">
                    <h3>🛡️ Protection de la vie privée active</h3>
                    <div class="info-item">
                        <span class="info-icon">🚫</span>
                        <span>Aucun historique enregistré</span>
                    </div>
                    <div class="info-item">
                        <span class="info-icon">🍪</span>
                        <span>Cookies supprimés à la fermeture</span>
                    </div>
                    <div class="info-item">
                        <span class="info-icon">💾</span>
                        <span>Pas de cache persistant</span>
                    </div>
                    <div class="info-item">
                        <span class="info-icon">🔐</span>
                        <span>Données temporaires uniquement</span>
                    </div>
                </div>
            </div>
        </body>
        </html>
        """
        vue_web.setHtml(html_accueil_prive)
    
    def charger_page_accueil_dans_vue(self, vue_web):
        """Charger la page d'accueil dans une vue web spécifique"""
        # Page d'accueil HTML optimisée
        html_accueil = """
        <!DOCTYPE html>
        <html>
        <head>
            <title>Nouvel onglet - Navigateur Haute Performance</title>
            <meta charset="utf-8">
            <style>
                * { margin: 0; padding: 0; box-sizing: border-box; }
                body {
                    font-family: 'Segoe UI', -apple-system, BlinkMacSystemFont, sans-serif;
                    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                    color: white;
                    min-height: 100vh;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                }
                .container {
                    max-width: 800px;
                    width: 90%;
                    background: rgba(255, 255, 255, 0.1);
                    border-radius: 20px;
                    padding: 40px;
                    backdrop-filter: blur(15px);
                    box-shadow: 0 20px 40px rgba(0,0,0,0.2);
                    text-align: center;
                }
                h1 {
                    font-size: 2.5em;
                    margin-bottom: 20px;
                    background: linear-gradient(45deg, #fff, #f0f0f0);
                    -webkit-background-clip: text;
                    -webkit-text-fill-color: transparent;
                }
                .search-box {
                    margin: 30px 0;
                }
                .search-input {
                    width: 80%;
                    padding: 15px 20px;
                    font-size: 16px;
                    border: none;
                    border-radius: 25px;
                    background: rgba(255, 255, 255, 0.9);
                    color: #333;
                    outline: none;
                }
                .quick-links {
                    display: grid;
                    grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
                    gap: 15px;
                    margin-top: 30px;
                }
                .quick-link {
                    background: rgba(255, 255, 255, 0.15);
                    border-radius: 10px;
                    padding: 20px;
                    text-decoration: none;
                    color: white;
                    transition: all 0.3s ease;
                    cursor: pointer;
                }
                .quick-link:hover {
                    transform: translateY(-5px);
                    background: rgba(255, 255, 255, 0.25);
                }
                .link-icon {
                    font-size: 2em;
                    margin-bottom: 10px;
                    display: block;
                }
            </style>
        </head>
        <body>
            <div class="container">
                <h1>🌐 Nouvel Onglet</h1>
                <div class="search-box">
                    <input type="text" class="search-input" placeholder="Rechercher ou saisir une URL..." 
                           onkeypress="if(event.key==='Enter') window.location.href='https://www.google.com/search?q='+encodeURIComponent(this.value)">
                </div>
                <div class="quick-links">
                    <a href="https://www.google.com" class="quick-link">
                        <span class="link-icon">🔍</span>
                        Google
                    </a>
                    <a href="https://www.youtube.com" class="quick-link">
                        <span class="link-icon">📺</span>
                        YouTube
                    </a>
                    <a href="https://www.github.com" class="quick-link">
                        <span class="link-icon">💻</span>
                        GitHub
                    </a>
                    <a href="https://www.wikipedia.org" class="quick-link">
                        <span class="link-icon">📚</span>
                        Wikipedia
                    </a>
                </div>
            </div>
        </body>
        </html>
        """
        vue_web.setHtml(html_accueil)
    
    def fermer_onglet(self, index):
        """Fermer un onglet avec nettoyage mémoire"""
        if self.onglets.count() > 1:
            widget = self.onglets.widget(index)
            self.onglets.removeTab(index)
            
            # Nettoyer la mémoire
            if widget:
                widget.deleteLater()
            
            # Forcer le garbage collection
            gc.collect()
        else:
            self.close()
    
    def onglet_change(self, index):
        """Gérer le changement d'onglet"""
        vue_web = self.onglets.widget(index)
        if vue_web:
            url = vue_web.url().toString()
            self.barre_adresse.setText(url)
            self.mettre_a_jour_boutons_navigation()
    
    def vue_web_actuelle(self):
        return self.onglets.currentWidget()
    
    def naviguer(self):
        url = self.barre_adresse.text().strip()
        if url:
            self.charger_url(url)
    
    def charger_url(self, url):
        """Charger une URL avec optimisations"""
        # Ajouter https:// si nécessaire
        if not url.startswith(('http://', 'https://')):
            if '.' in url and ' ' not in url:
                url = 'https://' + url
            else:
                # Recherche Google optimisée
                url = f"https://www.google.com/search?q={url.replace(' ', '+')}"
        
        vue_web = self.vue_web_actuelle()
        if vue_web:
            # Vérifier le cache
            if url in self.cache_pages:
                cache_info = self.cache_pages[url]
                if datetime.now() - cache_info['timestamp'] < timedelta(minutes=30):
                    self.label_statut.setText("Chargé depuis le cache")
            
            vue_web.setUrl(QUrl(url))
            self.historique.append(url)
            
            # Limiter l'historique
            if len(self.historique) > 1000:
                self.historique = self.historique[-500:]
    
    def chargement_commence(self):
        """Gérer le début du chargement"""
        self.barre_progression.setVisible(True)
        self.barre_progression.setValue(0)
        self.label_statut.setText("Chargement en cours...")
        self.debut_chargement = datetime.now()
    
    def progression_chargement(self, progress):
        """Mettre à jour la progression"""
        self.barre_progression.setValue(progress)
    
    def chargement_termine(self, success):
        """Gérer la fin du chargement"""
        self.barre_progression.setVisible(False)
        
        if success:
            duree = datetime.now() - self.debut_chargement
            self.label_statut.setText(f"Chargé en {duree.total_seconds():.2f}s")
            self.label_vitesse.setText(f"⚡ {duree.total_seconds():.1f}s")
            
            # Mettre en cache
            vue_web = self.vue_web_actuelle()
            if vue_web:
                url = vue_web.url().toString()
                self.cache_pages[url] = {
                    'timestamp': datetime.now(),
                    'title': vue_web.title()
                }
        else:
            self.label_statut.setText("Erreur de chargement")
        
        self.mettre_a_jour_boutons_navigation()
    
    def mettre_a_jour_boutons_navigation(self):
        """Mettre à jour l'état des boutons de navigation"""
        vue_web = self.vue_web_actuelle()
        if vue_web:
            history = vue_web.history()
            self.btn_retour.setEnabled(history.canGoBack())
            self.btn_avancer.setEnabled(history.canGoForward())
    
    def retour(self):
        vue_web = self.vue_web_actuelle()
        if vue_web:
            vue_web.back()
    
    def avancer(self):
        vue_web = self.vue_web_actuelle()
        if vue_web:
            vue_web.forward()
    
    def actualiser(self):
        vue_web = self.vue_web_actuelle()
        if vue_web:
            vue_web.reload()
    
    def nettoyer_memoire(self):
        """Nettoyer la mémoire périodiquement"""
        # Nettoyer le cache des pages anciennes
        now = datetime.now()
        urls_to_remove = []
        
        for url, info in self.cache_pages.items():
            if now - info['timestamp'] > timedelta(hours=2):
                urls_to_remove.append(url)
        
        for url in urls_to_remove:
            del self.cache_pages[url]
        
        # Forcer le garbage collection
        gc.collect()
        
        # Mettre à jour l'affichage mémoire
        self.mettre_a_jour_statut_memoire()
    
    def mettre_a_jour_statut_memoire(self):
        """Mettre à jour l'affichage de l'utilisation mémoire"""
        try:
            import psutil
            process = psutil.Process()
            memory_mb = process.memory_info().rss / 1024 / 1024
            self.label_memoire.setText(f"💾 {memory_mb:.0f}MB")
        except ImportError:
            self.label_memoire.setText("💾 N/A")
    
    def sauvegarde_automatique(self):
        """Sauvegarde automatique des données"""
        self.sauvegarder_favoris()
        self.derniere_activite = datetime.now()
    
    def nettoyer_cache(self):
        """Nettoyer manuellement le cache"""
        self.cache_pages.clear()
        self.profile.clearHttpCache()
        gc.collect()
        QMessageBox.information(self, "Cache nettoyé", 
                              "Le cache a été nettoyé avec succès!")
        self.mettre_a_jour_statut_memoire()
    
    def optimiser_performances(self):
        """Optimiser les performances manuellement"""
        # Nettoyer la mémoire
        self.nettoyer_memoire()
        
        # Fermer les onglets inactifs (garder seulement l'actuel)
        current_index = self.onglets.currentIndex()
        for i in range(self.onglets.count() - 1, -1, -1):
            if i != current_index:
                self.fermer_onglet(i)
        
        QMessageBox.information(self, "Optimisation terminée", 
                              "Les performances ont été optimisées!")
    
    def aller_accueil(self):
        # Page d'accueil HTML optimisée
        html_accueil = """
        <!DOCTYPE html>
        <html>
        <head>
            <title>Accueil - Navigateur Haute Performance</title>
            <meta charset="utf-8">
            <style>
                * { margin: 0; padding: 0; box-sizing: border-box; }
                body {
                    font-family: 'Segoe UI', -apple-system, BlinkMacSystemFont, sans-serif;
                    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                    color: white;
                    min-height: 100vh;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                }
                .container {
                    max-width: 1000px;
                    width: 90%;
                    background: rgba(255, 255, 255, 0.1);
                    border-radius: 20px;
                    padding: 40px;
                    backdrop-filter: blur(15px);
                    box-shadow: 0 20px 40px rgba(0,0,0,0.2);
                }
                h1 {
                    font-size: 3em;
                    margin-bottom: 10px;
                    text-align: center;
                    text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
                    background: linear-gradient(45deg, #fff, #f0f0f0);
                    -webkit-background-clip: text;
                    -webkit-text-fill-color: transparent;
                }
                .subtitle {
                    text-align: center;
                    font-size: 1.2em;
                    margin-bottom: 40px;
                    opacity: 0.9;
                }
                .sites-grid {
                    display: grid;
                    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
                    gap: 20px;
                    margin: 40px 0;
                }
                .site-card {
                    background: rgba(255, 255, 255, 0.15);
                    border-radius: 15px;
                    padding: 25px;
                    text-decoration: none;
                    color: white;
                    transition: all 0.3s ease;
                    border: 1px solid rgba(255, 255, 255, 0.2);
                    text-align: center;
                    cursor: pointer;
                }
                .site-card:hover {
                    transform: translateY(-8px) scale(1.02);
                    background: rgba(255, 255, 255, 0.25);
                    box-shadow: 0 15px 30px rgba(0,0,0,0.2);
                }
                .site-icon {
                    font-size: 2.5em;
                    margin-bottom: 15px;
                    display: block;
                }
                .site-name {
                    font-size: 1.1em;
                    font-weight: 600;
                    margin-bottom: 8px;
                }
                .site-desc {
                    font-size: 0.9em;
                    opacity: 0.8;
                }
                .performance-info {
                    margin-top: 30px;
                    text-align: center;
                    padding: 20px;
                    background: rgba(0,0,0,0.2);
                    border-radius: 10px;
                }
                .perf-stat {
                    display: inline-block;
                    margin: 0 15px;
                    padding: 10px;
                }
                .search-box {
                    margin: 30px 0;
                    text-align: center;
                }
                .search-input {
                    width: 60%;
                    padding: 15px 20px;
                    font-size: 16px;
                    border: none;
                    border-radius: 25px;
                    background: rgba(255,255,255,0.9);
                    color: #333;
                    outline: none;
                }
                .search-input::placeholder {
                    color: #666;
                }
            </style>
        </head>
        <body>
            <div class="container">
                <h1>🚀 MyWebBrowser, navigez avec rapidité.</h1>
                <p class="subtitle">Navigation rapide et optimisée</p>
                
                <div class="search-box">
                    <input type="text" class="search-input" placeholder="🔍 Rechercher ou entrer une URL..." 
                           onkeypress="if(event.key==='Enter') window.location.href='https://www.google.com/search?q='+encodeURIComponent(this.value)">
                </div>
                
                <div class="sites-grid">
                    <div class="site-card" onclick="window.location.href='https://www.google.com'">
                        <span class="site-icon">🔍</span>
                        <div class="site-name">Google</div>
                        <div class="site-desc">Moteur de recherche</div>
                    </div>
                    
                    <div class="site-card" onclick="window.location.href='https://www.youtube.com'">
                        <span class="site-icon">📺</span>
                        <div class="site-name">YouTube</div>
                        <div class="site-desc">Vidéos en ligne</div>
                    </div>
                    
                    <div class="site-card" onclick="window.location.href='https://www.twitch.tv'">
                        <span class="site-icon">💻</span>
                        <div class="site-name">Twitch</div>
                        <div class="site-desc">Streaming en direct</div>
                    </div>
                    
                    <div class="site-card" onclick="window.location.href='https://www.wikipedia.org'">
                        <span class="site-icon">📚</span>
                        <div class="site-name">Wikipedia</div>
                        <div class="site-desc">Encyclopédie libre</div>
                    </div>
                    
                    <div class="site-card" onclick="window.location.href='https://www.discord.com'">
                        <span class="site-icon">💬</span>
                        <div class="site-name">Discord</div>
                        <div class="site-desc">Communautés</div>
                    </div>
                     <div class="site-card" onclick="window.location.href='https://mail.google.com'">
                        <span class="site-icon">📧</span>
                        <div class="site-name">Gmail</div>
                        <div class="site-desc">Email professionnel</div>
                    </div>
                    <div class="site-card" onclick="window.location.href='https://x.com'">
                        <span class="site-icon">🐦</span>
                        <div class="site-name">X (Twitter)</div>
                        <div class="site-desc">Questions & réponses</div>
                    </div>
                    <div class="site-card" onclick="window.location.href='https://www.reddit.com'">
                        <span class="site-icon">📰</span>
                        <div class="site-name">Reddit</div>
                        <div class="site-desc">Communautés</div>
                    </div>
                </div>
                
                <div class="performance-info">
                    <h3>⚡ Optimisations Actives</h3>
                    <div class="perf-stat">🚀 Cache intelligent</div>
                    <div class="perf-stat">🛡️ Blocage des pubs</div>
                    <div class="perf-stat">💾 Gestion mémoire</div>
                    <div class="perf-stat">⚡ Chargement rapide</div>
                    <div class="perf-stat">🛡️ Sécurisé</div>
                    <div class="perf-stat">🤖 Version BETA</div>
                    <div class="perf-stat">🇫🇷 Navigateur Français</div>
                </div>
            </div>
        </body>
        </html>
        """
        
        vue_web = self.vue_web_actuelle()
        if vue_web:
            vue_web.setHtml(html_accueil)
            self.barre_adresse.setText("")
            self.label_statut.setText("Page d'accueil")
    
    def url_changee(self, url):
        self.barre_adresse.setText(url.toString())
        # Mettre à jour l'indicateur de sécurité
        self.mettre_a_jour_indicateur_securite()
    
    def titre_change(self, titre):
        index = self.onglets.currentIndex()
        if index >= 0:
            # Vérifier si c'est un onglet privé
            vue_web = self.onglets.widget(index)
            is_private = hasattr(vue_web, 'is_private') and vue_web.is_private
            
            # Limiter la longueur du titre pour l'onglet
            titre_court = titre[:20] + "..." if len(titre) > 20 else titre
            
            # Ajouter l'icône de cadenas pour les onglets privés
            if is_private:
                titre_court = "🔒 " + titre_court
            
            self.onglets.setTabText(index, titre_court)
            self.onglets.setTabToolTip(index, titre)  # Titre complet en tooltip
    
    def ajouter_favori(self):
        vue_web = self.vue_web_actuelle()
        if vue_web:
            url = vue_web.url().toString()
            titre = vue_web.title() or "Page sans titre"
            
            if url and url != "about:blank":
                nom, ok = QInputDialog.getText(self, 'Ajouter un favori', 
                                             'Nom du favori:', text=titre)
                if ok and nom:
                    self.favoris[nom] = url
                    self.sauvegarder_favoris()
                    QMessageBox.information(self, 'Favori ajouté', 
                                          f'"{nom}" a été ajouté aux favoris!')
    
    def gerer_favoris(self):
        dialog = QDialog(self)
        dialog.setWindowTitle("Gestion des Favoris")
        dialog.setGeometry(200, 200, 500, 400)
        
        layout = QVBoxLayout(dialog)
        
        # Liste des favoris
        liste = QListWidget()
        for nom, url in self.favoris.items():
            liste.addItem(f"{nom} - {url}")
        layout.addWidget(liste)
        
        # Boutons
        boutons_layout = QHBoxLayout()
        
        btn_ouvrir = QPushButton("Ouvrir")
        btn_ouvrir.clicked.connect(lambda: self.ouvrir_favori_selectionne(liste))
        boutons_layout.addWidget(btn_ouvrir)
        
        btn_supprimer = QPushButton("Supprimer")
        btn_supprimer.clicked.connect(lambda: self.supprimer_favori_selectionne(liste))
        boutons_layout.addWidget(btn_supprimer)
        
        btn_fermer = QPushButton("Fermer")
        btn_fermer.clicked.connect(dialog.close)
        boutons_layout.addWidget(btn_fermer)
        
        layout.addLayout(boutons_layout)
        
        dialog.exec_()
    
    def ouvrir_favori_selectionne(self, liste):
        item = liste.currentItem()
        if item:
            texte = item.text()
            nom = texte.split(" - ")[0]
            if nom in self.favoris:
                self.charger_url(self.favoris[nom])
    
    def supprimer_favori_selectionne(self, liste):
        item = liste.currentItem()
        if item:
            texte = item.text()
            nom = texte.split(" - ")[0]
            if nom in self.favoris:
                reply = QMessageBox.question(self, 'Confirmer', 
                                           f'Supprimer le favori "{nom}" ?')
                if reply == QMessageBox.Yes:
                    del self.favoris[nom]
                    self.sauvegarder_favoris()
                    liste.takeItem(liste.row(item))
    
    def a_propos(self):
        QMessageBox.about(self, "À propos", 
                         "Navigateur Web Haute Performance\n"
                         "Version 2.0 Optimisée\n\n"
                         "Fonctionnalités:\n"
                         "• Moteur Chromium intégré\n"
                         "• Cache intelligent\n"
                         "• Gestion mémoire optimisée\n"
                         "• Interface moderne\n"
                         "• Blocage des publicités\n"
                         "• Navigation par onglets\n\n"
                         "Développé avec PyQt5 et QtWebEngine")
    
    def charger_favoris(self):
        try:
            if os.path.exists("favoris_pyqt.json"):
                with open("favoris_pyqt.json", "r", encoding="utf-8") as f:
                    return json.load(f)
        except Exception as e:
            print(f"Erreur chargement favoris: {e}")
        return {}
    
    def sauvegarder_favoris(self):
        try:
            with open("favoris_pyqt.json", "w", encoding="utf-8") as f:
                json.dump(self.favoris, f, ensure_ascii=False, indent=2)
        except Exception as e:
            print(f"Erreur sauvegarde favoris: {e}")

    def fermer_onglet_actuel(self):
        """Ferme l'onglet actuellement actif"""
        index_actuel = self.onglets.currentIndex()
        if self.onglets.count() > 1:
            self.fermer_onglet(index_actuel)
        else:
            self.close()

    def nouvelle_fenetre(self):
        """Ouvre une nouvelle fenêtre du navigateur"""
        nouvelle_fenetre = NavigateurWebOptimise()
        nouvelle_fenetre.show()

    def focus_barre_adresse(self):
        """Met le focus sur la barre d'adresse"""
        self.barre_adresse.setFocus()
        self.barre_adresse.selectAll()

    def rechercher_dans_page(self):
        """Ouvre la fonction de recherche dans la page (placeholder)"""
        # Cette fonctionnalité nécessiterait une implémentation plus complexe
        # Pour l'instant, on affiche juste un message
        QMessageBox.information(self, "Recherche", "Fonction de recherche dans la page à implémenter")

    def zoom_avant(self):
        """Augmente le zoom de la page"""
        vue_web = self.vue_web_actuelle()
        if vue_web:
            facteur_zoom = vue_web.zoomFactor()
            nouveau_zoom = min(facteur_zoom * 1.1, 3.0)  # Maximum 300%
            vue_web.setZoomFactor(nouveau_zoom)

    def zoom_arriere(self):
        """Diminue le zoom de la page"""
        vue_web = self.vue_web_actuelle()
        if vue_web:
            facteur_zoom = vue_web.zoomFactor()
            nouveau_zoom = max(facteur_zoom / 1.1, 0.25)  # Minimum 25%
            vue_web.setZoomFactor(nouveau_zoom)

    def zoom_reset(self):
        """Remet le zoom à 100%"""
        vue_web = self.vue_web_actuelle()
        if vue_web:
            vue_web.setZoomFactor(1.0)

    def actualiser_force(self):
        """Actualise la page en ignorant le cache"""
        vue_web = self.vue_web_actuelle()
        if vue_web:
            vue_web.page().triggerAction(QWebEnginePage.ReloadAndBypassCache)
    
    def gerer_telechargement(self, download_item):
        """Gérer les téléchargements de fichiers"""
        # Initialiser la liste des téléchargements si elle n'existe pas
        if not hasattr(self, 'telechargements_actifs'):
            self.telechargements_actifs = []
        
        # Obtenir le nom de fichier suggéré
        nom_fichier = download_item.suggestedFileName()
        
        # Demander à l'utilisateur où sauvegarder le fichier
        chemin_telechargement = QFileDialog.getSaveFileName(
            self, 
            "Télécharger le fichier", 
            os.path.join(QStandardPaths.writableLocation(QStandardPaths.DownloadLocation), nom_fichier),
            "Tous les fichiers (*.*)"
        )[0]
        
        if chemin_telechargement:
            # Définir le chemin de téléchargement
            download_item.setPath(chemin_telechargement)
            
            # Ajouter à la liste des téléchargements actifs
            telechargement_info = {
                'nom': os.path.basename(chemin_telechargement),
                'chemin': chemin_telechargement,
                'statut': 'En cours...',
                'item': download_item
            }
            self.telechargements_actifs.append(telechargement_info)
            
            # Connecter les signaux pour suivre le progrès
            download_item.downloadProgress.connect(
                lambda received, total, info=telechargement_info: 
                self.progression_telechargement(received, total, info)
            )
            download_item.finished.connect(
                lambda info=telechargement_info: 
                self.telechargement_termine(info)
            )
            
            # Accepter le téléchargement
            download_item.accept()
            
            # Afficher un message de confirmation
            self.label_statut.setText(f"Téléchargement de {nom_fichier} en cours...")
        else:
            # Annuler le téléchargement si l'utilisateur annule
            download_item.cancel()
    
    def progression_telechargement(self, bytes_received, bytes_total, telechargement_info):
        """Afficher la progression du téléchargement"""
        if bytes_total > 0:
            pourcentage = int((bytes_received / bytes_total) * 100)
            telechargement_info['statut'] = f"{pourcentage}% ({bytes_received}/{bytes_total} octets)"
            self.label_statut.setText(f"Téléchargement: {pourcentage}% - {telechargement_info['nom']}")
    
    def telechargement_termine(self, telechargement_info):
        """Gérer la fin du téléchargement"""
        download_item = telechargement_info['item']
        if download_item.state() == QWebEngineDownloadItem.DownloadCompleted:
            telechargement_info['statut'] = 'Terminé ✅'
            self.label_statut.setText(f"Téléchargement terminé: {telechargement_info['nom']}")
            QMessageBox.information(self, "Téléchargement terminé", 
                                  f"Le fichier a été téléchargé avec succès:\n{download_item.path()}")
        elif download_item.state() == QWebEngineDownloadItem.DownloadCancelled:
            telechargement_info['statut'] = 'Annulé ❌'
            self.label_statut.setText("Téléchargement annulé")
        else:
            telechargement_info['statut'] = 'Erreur ⚠️'
            self.label_statut.setText("Erreur lors du téléchargement")
            QMessageBox.warning(self, "Erreur de téléchargement", 
                              "Une erreur s'est produite lors du téléchargement.")
    
    def verifier_securite_site(self, url):
        """Vérifier si le site est sécurisé (HTTPS)"""
        if url.scheme() == "https":
            return True, "🔒 Site sécurisé (HTTPS)"
        elif url.scheme() == "http":
            return False, "⚠️ Site non sécurisé (HTTP)"
        else:
            return None, "❓ Protocole inconnu"
    
    def mettre_a_jour_indicateur_securite(self):
        """Mettre à jour l'indicateur de sécurité dans la barre d'adresse"""
        vue_web = self.vue_web_actuelle()
        if vue_web:
            url = vue_web.url()
            est_securise, message = self.verifier_securite_site(url)
            
            # Mettre à jour le tooltip de la barre d'adresse
            self.barre_adresse.setToolTip(message)
            
            # Changer la couleur de la barre d'adresse selon la sécurité
            if est_securise:
                self.barre_adresse.setStyleSheet("""
                    QLineEdit {
                        background: qlineargradient(x1:0, y1:0, x2:0, y2:1, 
                            stop:0 #4C566A, stop:1 #3B4252);
                        color: #ECEFF4;
                        border: 2px solid #A3BE8C;
                        border-radius: 8px;
                        padding: 8px;
                        font-size: 14px;
                        selection-background-color: #88C0D0;
                    }
                """)
            elif est_securise is False:
                self.barre_adresse.setStyleSheet("""
                    QLineEdit {
                        background: qlineargradient(x1:0, y1:0, x2:0, y2:1, 
                            stop:0 #4C566A, stop:1 #3B4252);
                        color: #ECEFF4;
                        border: 2px solid #BF616A;
                        border-radius: 8px;
                        padding: 8px;
                        font-size: 14px;
                        selection-background-color: #88C0D0;
                    }
                """)
            else:
                # Style par défaut
                self.barre_adresse.setStyleSheet("""
                    QLineEdit {
                        background: qlineargradient(x1:0, y1:0, x2:0, y2:1, 
                            stop:0 #4C566A, stop:1 #3B4252);
                        color: #ECEFF4;
                        border: 2px solid #5E81AC;
                        border-radius: 8px;
                        padding: 8px;
                        font-size: 14px;
                        selection-background-color: #88C0D0;
                    }
                """)

    def ouvrir_gestionnaire_telechargements(self):
        """Ouvre une fenêtre de gestionnaire de téléchargements"""
        dialog = QDialog(self)
        dialog.setWindowTitle("Gestionnaire de téléchargements")
        dialog.setGeometry(200, 200, 600, 400)
        
        layout = QVBoxLayout()
        
        # Titre
        titre = QLabel("Téléchargements")
        titre.setStyleSheet("font-size: 18px; font-weight: bold; margin-bottom: 10px; color: #2D3748;")
        layout.addWidget(titre)
        
        # Liste des téléchargements (pour l'instant vide)
        liste_telechargements = QListWidget()
        liste_telechargements.setStyleSheet("""
            QListWidget {
                border: 1px solid #E2E8F0;
                border-radius: 8px;
                background-color: #FFFFFF;
                padding: 8px;
                font-size: 14px;
            }
            QListWidget::item {
                padding: 12px;
                border-bottom: 1px solid #F7FAFC;
                border-radius: 4px;
                margin: 2px 0;
            }
            QListWidget::item:selected {
                background-color: #EBF8FF;
                border: 1px solid #3182CE;
            }
            QListWidget::item:hover {
                background-color: #F7FAFC;
            }
        """)
        
        # Message si aucun téléchargement
        if not hasattr(self, 'telechargements_actifs') or not self.telechargements_actifs:
            liste_telechargements.addItem("📥 Aucun téléchargement en cours ou terminé")
        else:
            for telechargement in self.telechargements_actifs:
                liste_telechargements.addItem(f"📁 {telechargement['nom']} - {telechargement['statut']}")
        
        layout.addWidget(liste_telechargements)
        
        # Boutons d'action
        boutons_layout = QHBoxLayout()
        
        btn_effacer = QPushButton("🗑️ Effacer l'historique")
        btn_effacer.setStyleSheet("""
            QPushButton {
                background-color: #E53E3E;
                color: white;
                border: none;
                padding: 10px 20px;
                border-radius: 6px;
                font-weight: bold;
                font-size: 14px;
            }
            QPushButton:hover {
                background-color: #C53030;
            }
            QPushButton:pressed {
                background-color: #9C2A2A;
            }
        """)
        btn_effacer.clicked.connect(lambda: self.effacer_historique_telechargements(liste_telechargements))
        
        btn_ouvrir_dossier = QPushButton("📂 Ouvrir le dossier")
        btn_ouvrir_dossier.setStyleSheet("""
            QPushButton {
                background-color: #3182CE;
                color: white;
                border: none;
                padding: 10px 20px;
                border-radius: 6px;
                font-weight: bold;
                font-size: 14px;
            }
            QPushButton:hover {
                background-color: #2C5282;
            }
            QPushButton:pressed {
                background-color: #2A4365;
            }
        """)
        btn_ouvrir_dossier.clicked.connect(self.ouvrir_dossier_telechargements)
        
        btn_fermer = QPushButton("✖️ Fermer")
        btn_fermer.setStyleSheet("""
            QPushButton {
                background-color: #718096;
                color: white;
                border: none;
                padding: 10px 20px;
                border-radius: 6px;
                font-weight: bold;
                font-size: 14px;
            }
            QPushButton:hover {
                background-color: #4A5568;
            }
            QPushButton:pressed {
                background-color: #2D3748;
            }
        """)
        btn_fermer.clicked.connect(dialog.close)
        
        boutons_layout.addWidget(btn_effacer)
        boutons_layout.addWidget(btn_ouvrir_dossier)
        boutons_layout.addStretch()
        boutons_layout.addWidget(btn_fermer)
        
        layout.addLayout(boutons_layout)
        dialog.setLayout(layout)
        
        # Appliquer le style moderne au dialog
        dialog.setStyleSheet("""
            QDialog {
                background-color: #F7FAFC;
                border-radius: 12px;
            }
        """)
        
        dialog.exec_()

    def effacer_historique_telechargements(self, liste_widget):
        """Efface l'historique des téléchargements"""
        if hasattr(self, 'telechargements_actifs'):
            self.telechargements_actifs.clear()
        
        liste_widget.clear()
        liste_widget.addItem("📥 Aucun téléchargement en cours ou terminé")
        
        QMessageBox.information(self, "Historique effacé", "L'historique des téléchargements a été effacé avec succès.")

    def ouvrir_dossier_telechargements(self):
        """Ouvre le dossier de téléchargements par défaut"""
        import subprocess
        import platform
        
        # Obtenir le dossier de téléchargements par défaut
        dossier_telechargements = QStandardPaths.writableLocation(QStandardPaths.DownloadLocation)
        
        try:
            if platform.system() == "Windows":
                os.startfile(dossier_telechargements)
            elif platform.system() == "Darwin":  # macOS
                subprocess.run(["open", dossier_telechargements])
            else:  # Linux
                subprocess.run(["xdg-open", dossier_telechargements])
        except Exception as e:
            QMessageBox.warning(self, "Erreur", f"Impossible d'ouvrir le dossier de téléchargements:\n{str(e)}")
    
    def closeEvent(self, event):
        """Gérer la fermeture de l'application"""
        self.sauvegarder_favoris()
        
        # Nettoyer les timers
        self.timer_nettoyage.stop()
        self.timer_sauvegarde.stop()
        
        # Nettoyer la mémoire
        self.cache_pages.clear()
        
        event.accept()

def main():
    app = QApplication(sys.argv)
    app.setApplicationName("Navigateur Haute Performance")
    app.setApplicationVersion("2.0")
    
    # Vérifier les dépendances
    try:
        from PyQt5.QtWebEngineWidgets import QWebEngineView
    except ImportError:
        QMessageBox.critical(None, "Erreur de dépendance", 
                           "QtWebEngine n'est pas installé.\n\n"
                           "Installez-le avec:\n"
                           "pip install PyQtWebEngine\n\n"
                           "Ou:\n"
                           "pip install PyQt5 PyQtWebEngine")
        sys.exit(1)
    
    # Écran de démarrage
    splash_pixmap = QPixmap(400, 300)
    splash_pixmap.fill(Qt.darkBlue)
    splash = QSplashScreen(splash_pixmap)
    splash.show()
    splash.showMessage("Chargement de MyWebBrowser...", 
                      Qt.AlignBottom | Qt.AlignCenter, Qt.white)
    
    app.processEvents()
    
    # Créer et afficher le navigateur
    navigateur = NavigateurWebOptimise()
    
    splash.finish(navigateur)
    navigateur.show()
    
    sys.exit(app.exec_())

if __name__ == "__main__":
    main()
